/* ==========================================================================
   GNASS CCTU CHAPTER — SCRIPT.JS
   Small, focused pieces of interactivity. Each section below does one job.
   ========================================================================== */

document.documentElement.classList.add('js-enabled');

/* ---------- 0. Ghana Time (Africa/Accra) Utilities ---------- */
// Ghana uses GMT (UTC+0) year-round — no DST. All date/time calculations
// for the countdown and schedule highlighting must use this timezone.
const GHANA_TZ = 'Africa/Accra';

/**
 * Returns a Date object representing "now" in Ghana Time.
 * Uses Intl.DateTimeFormat to get accurate time in Africa/Accra.
 */
function getGhanaNow() {
  // Get the current time in Ghana timezone
  const formatter = new Intl.DateTimeFormat('en-GB', {
    timeZone: GHANA_TZ,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  });
  const parts = formatter.formatToParts(new Date());
  const get = (type) => parts.find(p => p.type === type)?.value || '0';
  const year = Number(get('year'));
  const month = Number(get('month')) - 1; // JS months are 0-indexed
  const day = Number(get('day'));
  const hour = Number(get('hour'));
  const minute = Number(get('minute'));
  const second = Number(get('second'));
  return new Date(Date.UTC(year, month, day, hour, minute, second));
}

/**
 * Returns the day of week (0=Sun, 6=Sat) in Ghana Time.
 */
function getGhanaDay() {
  return getGhanaNow().getUTCDay();
}

/**
 * Returns the current hour (0-23) in Ghana Time.
 */
function getGhanaHour() {
  return getGhanaNow().getUTCHours();
}

/**
 * Returns the current minute (0-59) in Ghana Time.
 */
function getGhanaMinute() {
  return getGhanaNow().getUTCMinutes();
}

/* ---------- 1. Footer year ---------- */
// Keeps the copyright year correct forever, without editing HTML by hand.
document.getElementById('year').textContent = new Date().getFullYear();


/* ---------- 2. Dark mode toggle ---------- */
// We store the visitor's choice in localStorage so it's remembered on their
// next visit. The theme is applied by setting data-theme="dark" on <html>,
// which the CSS variables in style.css react to.
const root = document.documentElement;
const themeToggle = document.getElementById('theme-toggle');

function applyTheme(theme) {
  root.setAttribute('data-theme', theme);
  themeToggle.setAttribute('aria-pressed', theme === 'dark');
  themeToggle.setAttribute('aria-label', theme === 'dark' ? 'Turn off dark mode' : 'Turn on dark mode');
}

// On load: use the saved preference, or fall back to the visitor's OS setting.
const savedTheme = localStorage.getItem('gnass-theme');
const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
applyTheme(savedTheme || (prefersDark ? 'dark' : 'light'));

themeToggle.addEventListener('click', () => {
  const next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
  applyTheme(next);
  localStorage.setItem('gnass-theme', next);
});


/* ---------- 3. Mobile nav toggle ---------- */
// Opens/closes the menu list, and keeps the hamburger button's aria-expanded
// state in sync for screen readers.
const navToggle = document.getElementById('nav-toggle');
const mainNav = document.getElementById('main-nav');

navToggle.addEventListener('click', () => {
  const isOpen = mainNav.classList.toggle('is-open');
  navToggle.setAttribute('aria-expanded', isOpen);
});

// Close the menu automatically once a visitor taps a link.
mainNav.querySelectorAll('a').forEach((link) => {
  link.addEventListener('click', () => {
    mainNav.classList.remove('is-open');
    navToggle.setAttribute('aria-expanded', 'false');
  });
});


/* ---------- 4. Sabbath countdown (Ghana Time) ---------- */
// Ghana uses GMT/UTC+0, so the countdown uses UTC throughout regardless of
// the visitor's local timezone.
function getNextSabbathStart() {
  const now = getGhanaNow(); // Use Ghana Time
  const target = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(), 18, 0, 0, 0));

  const FRIDAY = 5;
  let daysUntilFriday = (FRIDAY - now.getUTCDay() + 7) % 7;

  // If it's already Friday but past 6 PM, jump to next week's Friday.
  if (daysUntilFriday === 0 && now > target) daysUntilFriday = 7;

  target.setUTCDate(now.getUTCDate() + daysUntilFriday);
  return target;
}

const statusEl = document.getElementById('countdown-status');
const dEl = document.getElementById('cd-days');
const hEl = document.getElementById('cd-hours');
const mEl = document.getElementById('cd-mins');
const sEl = document.getElementById('cd-secs');

function pad(num) { return String(num).padStart(2, '0'); }

function tickCountdown() {
  const now = getGhanaNow(); // Use Ghana Time
  const target = getNextSabbathStart();
  let diff = target - now;

  // Sabbath lasts roughly 24 hours. Once we're inside that window, diff goes
  // negative and we say "Sabbath is here".
  if (diff <= 0 && diff > -24 * 60 * 60 * 1000) {
    statusEl.textContent = 'Sabbath is here — enjoy the rest';
    dEl.textContent = hEl.textContent = mEl.textContent = sEl.textContent = '00';
    return;
  }
  if (diff <= 0) diff = target.setUTCDate(target.getUTCDate() + 7) - now; // safety fallback

  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
  const mins = Math.floor((diff / (1000 * 60)) % 60);
  const secs = Math.floor((diff / 1000) % 60);

  statusEl.textContent = 'Sabbath begins in';
  dEl.textContent = pad(days);
  hEl.textContent = pad(hours);
  mEl.textContent = pad(mins);
  sEl.textContent = pad(secs);
}

tickCountdown();
setInterval(tickCountdown, 1000);


/* ---------- 5. Weekly Schedule — Dynamic Activity Highlighting (Ghana Time) ---------- */
// Checks the current day/time in Ghana and applies the "current" class
// to the schedule card for the activity happening right now.
// If no activity is ongoing, removes the highlight from ALL cards.
const scheduleCards = document.querySelectorAll('.schedule-grid .schedule-card');

/**
 * Determines which schedule card (if any) should be highlighted based on
 * the current day and time in Ghana Time (Africa/Accra).
 * Schedule:
 * - Saturday: Sabbath School (9:00 AM - 10:30 AM)
 * - Saturday: Divine Service (10:30 AM - 12:30 PM approx)
 * - Wednesday: Vespers (6:30 PM - 8:00 PM approx)
 * - Friday: Adventist Youth (AY) (7:00 PM - 9:00 PM approx)
 */
function updateScheduleHighlight() {
  const day = getGhanaDay(); // 0=Sun, 1=Mon, ..., 6=Sat
  const hour = getGhanaHour();
  const minute = getGhanaMinute();
  const timeInMinutes = hour * 60 + minute;

  // Remove "current" from ALL cards first
  scheduleCards.forEach(card => card.classList.remove('current'));

  // Saturday = 6 (using getUTCDay since we're using UTC-based Ghana time)
  // Note: getUTCDay() returns 6 for Saturday
  const SATURDAY = 6;
  const WEDNESDAY = 3;
  const FRIDAY = 5;

  let targetCard = null;

  if (day === SATURDAY) {
    // Sabbath School: 9:00 AM - 10:30 AM (540 - 630 minutes)
    if (timeInMinutes >= 540 && timeInMinutes < 630) {
      targetCard = document.querySelector('.schedule-card:nth-child(1)');
    }
    // Divine Service: 10:30 AM - 12:30 PM (630 - 750 minutes)
    else if (timeInMinutes >= 630 && timeInMinutes < 750) {
      targetCard = document.querySelector('.schedule-card:nth-child(2)');
    }
  } else if (day === WEDNESDAY) {
    // Vespers: 6:30 PM - 8:00 PM (1110 - 1200 minutes)
    if (timeInMinutes >= 1110 && timeInMinutes < 1200) {
      targetCard = document.querySelector('.schedule-card:nth-child(3)');
    }
  } else if (day === FRIDAY) {
    // Adventist Youth (AY): 7:00 PM - 9:00 PM (1140 - 1260 minutes)
    if (timeInMinutes >= 1140 && timeInMinutes < 1260) {
      targetCard = document.querySelector('.schedule-card:nth-child(4)');
    }
  }

  // Apply highlight ONLY to current activity
  if (targetCard) {
    targetCard.classList.add('current');
  }
  // If no activity is ongoing, NO card gets highlighted (all highlights removed above)
}

// Run immediately and then every 30 seconds to keep in sync
updateScheduleHighlight();
setInterval(updateScheduleHighlight, 30 * 1000);


/* ---------- 5. Event filtering ---------- */
// Shows/hides .event-card elements based on which filter chip is active.
// This is a simple client-side filter, not a live/synced calendar.
const filterButtons = document.querySelectorAll('.filter-btn');
const eventCards = document.querySelectorAll('.event-card');

filterButtons.forEach((btn) => {
  btn.addEventListener('click', () => {
    filterButtons.forEach((b) => b.classList.remove('is-active'));
    btn.classList.add('is-active');

    const filter = btn.dataset.filter;
    document.querySelectorAll('.event-card').forEach((card) => {
      const show = filter === 'all' || card.dataset.category === filter;
      card.style.display = show ? '' : 'none';
    });
  });
});


/* ---------- 6. Prayer wall with SMS submission ---------- */
// Adds a new request card to the top of the list when the form is submitted.
// Opens the user's default SMS app with the prayer request pre-filled.
const prayerForm = document.getElementById('prayer-form');
const prayerList = document.getElementById('prayer-list');

prayerForm.addEventListener('submit', (event) => {
  event.preventDefault();

  const nameInput = document.getElementById('prayer-name');
  const requestInput = document.getElementById('prayer-request');
  const name = nameInput.value.trim() || 'Anonymous';
  const request = requestInput.value.trim();
  if (!request) return;

  // Create prayer request text for SMS
  const prayerRequestText = `Prayer Request from ${name}:\n${request}`;

  // Add to local prayer list immediately
  const item = document.createElement('li');
  item.className = 'prayer-item';
  const nameEl = document.createElement('strong');
  nameEl.textContent = name;
  const requestEl = document.createElement('p');
  requestEl.textContent = request;
  item.append(nameEl, requestEl);

  prayerList.prepend(item);
  prayerForm.reset();

  // Trigger SMS protocol
  window.location.href = "sms:0509511619?body=" + encodeURIComponent(prayerRequestText);
});


/* ---------- 7. Header shadow on scroll (small visual polish) ---------- */
const header = document.getElementById('site-header');
window.addEventListener('scroll', () => {
  header.style.boxShadow = window.scrollY > 8
    ? '0 4px 18px rgba(0,0,0,0.18)'
    : '0 2px 12px rgba(0,0,0,0.12)';
}, { passive: true });


/* ---------- 8. Live Adventist News Network feed ---------- */
// ANN publishes the source RSS. The public proxy only converts RSS to JSON so
// browsers can read it; each item still links back to adventist.news.
const annFeed = document.getElementById('ann-feed');
const annRssUrl = 'https://adventist.news/rss.xml';
const annProxyUrl = `https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(annRssUrl)}`;

function renderAnnFallback() {
  annFeed.innerHTML = '<p class="feed-status">The live feed is temporarily unavailable. <a href="https://adventist.news/" target="_blank" rel="noopener noreferrer">Read the latest ANN stories ↗</a></p>';
}

async function loadAnnFeed() {
  try {
    const response = await fetch(annProxyUrl, { headers: { Accept: 'application/json' } });
    if (!response.ok) throw new Error(`ANN feed request failed: ${response.status}`);
    const data = await response.json();
    const stories = (data.items || []).slice(0, 5);
    if (!stories.length) throw new Error('ANN feed returned no stories');
    annFeed.replaceChildren(...stories.map((story) => {
      const item = document.createElement('article');
      item.className = 'feed-item';
      const link = document.createElement('a');
      link.href = story.link;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      link.textContent = story.title;
      const date = document.createElement('time');
      date.dateTime = story.pubDate || '';
      date.textContent = story.pubDate ? new Date(story.pubDate).toLocaleDateString() : 'Latest update';
      item.append(link, date);
      return item;
    }));
  } catch (error) {
    renderAnnFallback();
  }
}

loadAnnFeed();
setInterval(loadAnnFeed, 15 * 60 * 1000);

/* ---------- 9. Dynamic Content Loading (Vercel API) ---------- */
// Fetches latest content from the public API and updates the page dynamically.
// Runs on load and polls every 30 seconds for live updates.
async function loadChapterContent() {
  try {
    const response = await fetch('/api/content', { headers: { Accept: 'application/json' } });
    if (!response.ok) return;
    const data = await response.json();
    
    // Update Latest Message section
    const message = data.latestMessage;
    if (message) {
      document.getElementById('latest-title').textContent = message.title;
      document.getElementById('latest-body').textContent = message.body;
      if (message.mediaUrl) {
        const media = document.getElementById('latest-media');
        if (message.mediaType && message.mediaType.startsWith('video/')) {
          media.querySelector('source').src = message.mediaUrl;
          media.load();
        } else if (message.mediaType && message.mediaType.startsWith('image/')) {
          const image = document.createElement('img');
          image.src = message.mediaUrl; image.alt = message.title;
          media.replaceWith(image);
        }
      }
    }
    
    // Update Events section
    if (Array.isArray(data.events) && data.events.length) {
      const list = document.getElementById('event-list');
      list.replaceChildren(...data.events.map((event) => {
        const card = document.createElement('article');
        card.className = 'event-card'; card.dataset.category = event.category;
        const date = new Date(event.eventDate);
        const dateEl = document.createElement('div'); dateEl.className = 'event-date';
        const day = document.createElement('strong'); day.textContent = date.getDate();
        const month = document.createElement('span'); month.textContent = date.toLocaleDateString('en', { month: 'short' });
        dateEl.append(day, month);
        const info = document.createElement('div'); info.className = 'event-info';
        const title = document.createElement('h3'); title.textContent = event.title;
        const description = document.createElement('p'); description.textContent = event.description || '';
        info.append(title, description); card.append(dateEl, info);
        const tag = document.createElement('span'); tag.className = `tag tag-${event.category}`; tag.textContent = event.category;
        card.append(tag); return card;
      }));
    }
    
    // Update Media/Reels section
    if (Array.isArray(data.mediaUpdates) && data.mediaUpdates.length) {
      const mediaList = document.getElementById('media-updates-list');
      const fallbackCards = [...mediaList.children];
      const updates = data.mediaUpdates.filter((update) =>
        typeof update.mediaUrl === 'string' &&
        (typeof update.mediaType === 'string' &&
          (update.mediaType.startsWith('image/') || update.mediaType.startsWith('video/')))
      );
      if (updates.length) {
        mediaList.replaceChildren(...updates.map((update) => {
          const card = document.createElement('article');
          card.className = 'reel-card';
          const thumb = document.createElement('div');
          thumb.className = 'reel-thumb';
          let media;
          if (update.mediaType.startsWith('video/')) {
            media = document.createElement('video');
            media.controls = true; media.preload = 'metadata';
            media.setAttribute('aria-label', update.title);
          } else {
            media = document.createElement('img');
            media.loading = 'lazy'; media.alt = update.title;
          }
          media.src = update.mediaUrl;
          thumb.append(media);
          const info = document.createElement('div');
          info.className = 'reel-info';
          const title = document.createElement('h3'); title.textContent = update.title;
          const body = document.createElement('span'); body.textContent = update.body || 'GNAAS CCTU update';
          info.append(title, body);
          card.append(thumb, info);
          return card;
        }));
      } else {
        // Keep the authored reels when records are malformed or unsupported.
        mediaList.replaceChildren(...fallbackCards);
      }
    }
  } catch (error) {
    console.warn('Content load failed, using static fallback:', error);
  }
}

// Initial load
loadChapterContent();

// Auto-refresh every 30 seconds for live updates
setInterval(loadChapterContent, 30 * 1000);


/* ---------- 10. Smooth scroll reveal animations ---------- */
const revealElements = document.querySelectorAll('.section, .latest-card, .schedule-grid, .about-grid, .ministry-grid, .media-row, .live-grid, .video-grid, .resource-row, .team-carousel, .prayer-form, .prayer-list, .give-options, .alumni-inner');
revealElements.forEach((element) => {
  element.classList.add('reveal-on-scroll');
  if (element.children.length > 1) element.classList.add('reveal-stagger');
});

if ('IntersectionObserver' in window) {
  const revealObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      entry.target.classList.add('is-in-view');
      observer.unobserve(entry.target);
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -6% 0px' });
  revealElements.forEach((element) => revealObserver.observe(element));
} else {
  revealElements.forEach((element) => element.classList.add('is-in-view'));
}


/* ---------- 9. Scroll reveal for the daily prayer meeting ---------- */
const prayerMeetingCard = document.querySelector('.prayer-meeting-card');
if (prayerMeetingCard && 'IntersectionObserver' in window) {
  const prayerMeetingObserver = new IntersectionObserver((entries, observer) => {
    if (entries[0].isIntersecting) {
      prayerMeetingCard.classList.add('is-visible');
      observer.disconnect();
    }
  }, { threshold: 0.2 });
  prayerMeetingObserver.observe(prayerMeetingCard);
} else if (prayerMeetingCard) {
  prayerMeetingCard.classList.add('is-visible');
}


/* ---------- 9. Executive hierarchy groups ---------- */
const executiveGroups = [...document.querySelectorAll('.team-grid-group')];
const executiveButton = document.getElementById('view-more-executives');
let executiveGroupIndex = 0;

executiveButton.addEventListener('click', () => {
  executiveGroups[executiveGroupIndex].hidden = true;
  executiveGroups[executiveGroupIndex].classList.remove('is-visible');
  executiveGroupIndex = (executiveGroupIndex + 1) % executiveGroups.length;
  executiveGroups[executiveGroupIndex].hidden = false;
  executiveGroups[executiveGroupIndex].classList.add('is-visible');
  const isLastGroup = executiveGroupIndex === executiveGroups.length - 1;
  executiveButton.setAttribute('aria-expanded', String(isLastGroup));
  executiveButton.setAttribute('aria-label', isLastGroup ? 'Return to core executives' : 'Show next executive group');
  executiveButton.innerHTML = isLastGroup ? 'Return to Core <span aria-hidden="true">↺</span>' : 'View More <span aria-hidden="true">+</span>';
});


/* ---------- 10. Event Highlights Slideshow (First Reel) ---------- */
// Automatic image slideshow for the first reel card
// Reads images from images/slideshows/ folder and cycles through them with smooth transitions

const slideshowTrack = document.getElementById('slideshow-track');
const slideshowIndicators = document.getElementById('slideshow-indicators');

// List of images in the slideshows folder
const slideshowImages = [
  'IMG-20260114-WA0023.jpg',
  'IMG-20260114-WA0024.jpg',
  'IMG-20260114-WA0025.jpg',
  'IMG-20260114-WA0026.jpg',
  'IMG-20260114-WA0027.jpg',
  'IMG-20260114-WA0028.jpg',
  'IMG-20260114-WA0029.jpg',
  'IMG-20260114-WA0030.jpg',
  'IMG-20260114-WA0031.jpg',
  'IMG-20260114-WA0032.jpg',
  'IMG-20260114-WA0033.jpg',
  'IMG-20260114-WA0047.jpg',
  'IMG-20260114-WA0048.jpg',
  'IMG-20260114-WA0049.jpg',
  'IMG-20260114-WA0050.jpg',
  'IMG-20260114-WA0051.jpg',
  'IMG-20260114-WA0052.jpg',
  'IMG-20260114-WA0053.jpg',
  'IMG-20260114-WA0054.jpg',
  'IMG-20260114-WA0055.jpg',
  'IMG-20260114-WA0056.jpg',
  'IMG-20260114-WA0057.jpg',
  'IMG-20260114-WA0058.jpg',
  'IMG-20260114-WA0059.jpg',
  'IMG-20260114-WA0060.jpg',
  'IMG-20260114-WA0061.jpg',
  'IMG-20260114-WA0062.jpg',
  'IMG-20260114-WA0063.jpg',
  'IMG-20260114-WA0064.jpg',
  'IMG-20260114-WA0065.jpg',
  'IMG-20260123-WA0024.jpg',
  'IMG-20260123-WA0025.jpg',
  'IMG-20260123-WA0026.jpg',
  'IMG-20260123-WA0027.jpg',
  'IMG-20260123-WA0028.jpg',
  'IMG-20260123-WA0029.jpg',
  'IMG-20260123-WA0030.jpg',
  'IMG-20260123-WA0031.jpg',
  'IMG-20260123-WA0032.jpg',
  'IMG-20260123-WA0033.jpg',
  'IMG-20260123-WA0034.jpg',
  'IMG-20260123-WA0035.jpg',
  'IMG-20260123-WA0036.jpg',
  'IMG-20260123-WA0037.jpg',
  'IMG-20260123-WA0038.jpg',
  'IMG-20260124-WA0002.jpg',
  'IMG-20260124-WA0003.jpg',
  'IMG-20260124-WA0004.jpg',
  'IMG-20260124-WA0005.jpg',
  'IMG-20260124-WA0006.jpg',
  'IMG-20260124-WA0007.jpg',
  'IMG-20260124-WA0008.jpg',
  'IMG-20260202-WA0022.jpg',
  'IMG-20260202-WA0024.jpg',
  'IMG-20260202-WA0043.jpg',
  'IMG-20260202-WA0107.jpg',
  'IMG-20260202-WA0191.jpg',
  'IMG-20260202-WA0229.jpg',
  'IMG-20260202-WA0238.jpg',
  'IMG-20260202-WA0241.jpg',
  'IMG-20260202-WA0246.jpg'
];

let currentSlide = 0;
let slideshowInterval;
const SLIDE_DURATION = 4000; // 4 seconds per slide

function initSlideshow() {
  if (!slideshowTrack || !slideshowIndicators) return;

  // Create slides
  slideshowImages.forEach((imageName, index) => {
    const slide = document.createElement('div');
    slide.className = 'slideshow-slide';
    slide.innerHTML = `<img src="images/slideshows/${imageName}" alt="Event Highlight ${index + 1}" loading="lazy" />`;
    slideshowTrack.appendChild(slide);

    // Create indicator
    const indicator = document.createElement('button');
    indicator.className = 'slideshow-indicator';
    indicator.setAttribute('aria-label', `Go to slide ${index + 1}`);
    indicator.addEventListener('click', () => goToSlide(index));
    slideshowIndicators.appendChild(indicator);
  });

  // Start slideshow
  startSlideshow();
}

function goToSlide(index) {
  if (index < 0) index = slideshowImages.length - 1;
  if (index >= slideshowImages.length) index = 0;
  
  currentSlide = index;
  const translateX = -currentSlide * 100;
  slideshowTrack.style.transform = `translateX(${translateX}%)`;
  
  // Update indicators
  const indicators = slideshowIndicators.querySelectorAll('.slideshow-indicator');
  indicators.forEach((indicator, i) => {
    indicator.classList.toggle('active', i === currentSlide);
  });
}

function nextSlide() {
  goToSlide(currentSlide + 1);
}

function startSlideshow() {
  // Initial indicator state
  goToSlide(0);
  
  slideshowInterval = setInterval(nextSlide, SLIDE_DURATION);
  
  // Pause on hover
  const slideshowContainer = document.querySelector('.slideshow-container');
  if (slideshowContainer) {
    slideshowContainer.addEventListener('mouseenter', () => {
      clearInterval(slideshowInterval);
    });
    
    slideshowContainer.addEventListener('mouseleave', () => {
      slideshowInterval = setInterval(nextSlide, SLIDE_DURATION);
    });
  }
}

// Initialize slideshow when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initSlideshow);
} else {
  initSlideshow();
}
